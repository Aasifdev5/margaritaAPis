<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Tu solicitud ha sido recibida</title>
</head>
<body>
    <p>Gracias por tu atención. Te contactará nuestro equipo comercial a la brevedad posible.</p>
</body>
</html>
