<div class="message">
    <h4>Hi ,</h4>
    <p>{{$mail_body->message}}</p>

    <p>
        <b>The {{get_option('app_name')}} Team</b>
    </p>
</div>
