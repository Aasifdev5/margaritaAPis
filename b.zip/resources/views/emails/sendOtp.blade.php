<!DOCTYPE html>
<html>
<head>
    <title>Verificación de OTP</title>
</head>
<body>
    <h1>Tu código OTP</h1>
    <p>Tu OTP es: <strong>{{ $otp }}</strong></p>
    <p>¡Gracias por usar nuestra aplicación!</p>
</body>
</html>
