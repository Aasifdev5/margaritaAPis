<?php $__env->startSection('title'); ?>
<?php echo e($statusCode); ?> - Error
<?php $__env->stopSection(); ?>
<?php $__env->startSection('others_content'); ?>
<div class="error-wrapper">
    <div class="container">
        <h3><?php echo e($statusCode); ?> - Something went wrong</h3>
        <p>Please contact support or try again later.</p>
        <a class="btn btn-primary" href="<?php echo e(route('dashboard')); ?>">BACK TO HOME PAGE</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('others.others_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aasif\Desktop\margaritaAPis\resources\views/others/error_pages/generic_error.blade.php ENDPATH**/ ?>