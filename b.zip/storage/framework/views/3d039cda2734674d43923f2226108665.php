<?php $__env->startSection('title'); ?>
Application Settings || General Setting
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>

    <!-- Page content area start -->

        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="breadcrumb__content">
                            <div class="breadcrumb__content__left">
                                <div class="breadcrumb__title">
                                    <h2><?php echo e(__('Application Settings')); ?></h2>
                                </div>
                            </div>
                            <div class="breadcrumb__content__right">
                                <nav aria-label="breadcrumb">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="<?php echo e(url('admin\dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__(@$title)); ?></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="card col-lg-3 col-md-4">
                        <?php echo $__env->make('admin.application_settings.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-lg-9 col-md-8">
                        <div class="card">
                            <div class="card-header"><h2><?php echo e(__(@$title)); ?></h2></div>
                            <div class="card-body">
                                <form action="<?php echo e(route('settings.general_setting.cms.update')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Name')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="app_name" value="<?php echo e($settings['app_name'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Email')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="app_email" value="<?php echo e($settings['app_email'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Contact Number')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="app_contact_number" value="<?php echo e($settings['app_contact_number'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Location')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="app_location" value="<?php echo e($settings['app_location'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Copyright')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="app_copyright" value="<?php echo e($settings['app_copyright'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Developed By')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="app_developed" value="<?php echo e($settings['app_developed'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label for="app_date_format" class="col-lg-3"><?php echo e(__('Date Format')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <select name="app_date_format" class="form-control">
                                                <option value="m/d/Y" <?php echo e(($settings['app_date_format'] ?? '') == 'm/d/Y' ? 'selected' : ''); ?>>
                                                    m/d/Y (eg. <?php echo e(\Carbon\Carbon::now()->format("m/d/Y")); ?>)
                                                </option>
                                                <option value="d/m/Y" <?php echo e(($settings['app_date_format'] ?? '') == 'd/m/Y' ? 'selected' : ''); ?>>
                                                    d/m/Y (eg. <?php echo e(\Carbon\Carbon::now()->format("d/m/Y")); ?>)
                                                </option>
                                                <option value="Y/m/d" <?php echo e(($settings['app_date_format'] ?? '') == 'Y/m/d' ? 'selected' : ''); ?>>
                                                    Y/m/d (eg. <?php echo e(\Carbon\Carbon::now()->format("Y/m/d")); ?>)
                                                </option>
                                                <option value="Y/d/m" <?php echo e(($settings['app_date_format'] ?? '') == 'Y/d/m' ? 'selected' : ''); ?>>
                                                    Y/d/m (eg. <?php echo e(\Carbon\Carbon::now()->format("Y/d/m")); ?>)
                                                </option>
                                                <option value="m-d-Y" <?php echo e(($settings['app_date_format'] ?? '') == 'm-d-Y' ? 'selected' : ''); ?>>
                                                    m-d-Y (eg. <?php echo e(\Carbon\Carbon::now()->format("m-d-Y")); ?>)
                                                </option>
                                                <option value="d-m-Y" <?php echo e(($settings['app_date_format'] ?? '') == 'd-m-Y' ? 'selected' : ''); ?>>
                                                    d-m-Y (eg. <?php echo e(\Carbon\Carbon::now()->format("d-m-Y")); ?>)
                                                </option>
                                                <option value="Y-m-d" <?php echo e(($settings['app_date_format'] ?? '') == 'Y-m-d' ? 'selected' : ''); ?>>
                                                    Y-m-d (eg. <?php echo e(\Carbon\Carbon::now()->format("Y-m-d")); ?>)
                                                </option>
                                                <option value="Y-d-m" <?php echo e(($settings['app_date_format'] ?? '') == 'Y-d-m' ? 'selected' : ''); ?>>
                                                    Y-d-m (eg. <?php echo e(\Carbon\Carbon::now()->format("Y-d-m")); ?>)
                                                </option>
                                                <option value="d M, Y" <?php echo e(($settings['app_date_format'] ?? '') == 'd M, Y' ? 'selected' : ''); ?>>
                                                    d M, Y (eg. <?php echo e(\Carbon\Carbon::now()->format("d M, Y")); ?>)
                                                </option>
                                                <option value="M d, Y" <?php echo e(($settings['app_date_format'] ?? '') == 'M d, Y' ? 'selected' : ''); ?>>
                                                    M d, Y (eg. <?php echo e(\Carbon\Carbon::now()->format("M d, Y")); ?>)
                                                </option>
                                                <option value="Y M, d" <?php echo e(($settings['app_date_format'] ?? '') == 'Y M, d' ? 'selected' : ''); ?>>
                                                    Y M, d (eg. <?php echo e(\Carbon\Carbon::now()->format("Y M, d")); ?>)
                                                </option>
                                                <option value="d F, Y" <?php echo e(($settings['app_date_format'] ?? '') == 'd F, Y' ? 'selected' : ''); ?>>
                                                    d F, Y (eg. <?php echo e(\Carbon\Carbon::now()->format("d F, Y")); ?>)
                                                </option>
                                                <option value="Y F, d" <?php echo e(($settings['app_date_format'] ?? '') == 'Y F, d' ? 'selected' : ''); ?>>
                                                    Y F, d (eg. <?php echo e(\Carbon\Carbon::now()->format("Y F, d")); ?>)
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label for="currency_id" class="col-lg-3"><?php echo e(__('Default Currency')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <select name="currency_id" class="form-control select2">
                                                <option value=""><?php echo e(__('Select Option')); ?></option>
                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($currency->id); ?>" <?php echo e($currency->id == (@$current_currency->id ?? null) ? 'selected' : ''); ?>>
                                                        <?php echo e($currency->symbol); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label for="FORCE_HTTPS" class="col-lg-3"><?php echo e(__('Force HTTPS')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <select name="FORCE_HTTPS" class="form-control select2">
                                                <option value="true" <?php echo e($settings['force_https'] ?? '' == true ? 'selected' : ''); ?>>
                                                    <?php echo e(__('TRUE')); ?>

                                                </option>
                                                <option value="false" <?php echo e($settings['force_https'] ?? '' == false ? 'selected' : ''); ?>>
                                                    <?php echo e(__('FALSE')); ?>

                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label for="app_date_format" class="col-lg-3"><?php echo e(__('Default Language')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <select name="language_id" class="form-control select2">
                                                <option value=""><?php echo e(__('Select Option')); ?></option>
                                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($language->id); ?>" <?php echo e($language->id == @$default_language->id ? 'selected' : ''); ?>><?php echo e($language->language); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label for="app_date_format" class="col-lg-3"><?php echo e(__('Time Zone')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <select name="TIMEZONE" class="form-control select2">
                                                <?php $__currentLoopData = getTimeZone(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($timezone); ?>" <?php echo e($timezone == ($settings['timezone'] ?? 'UTC') ? 'selected' : ''); ?>><?php echo e($timezone); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Platform Charge')); ?> (%) <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="number" min="0" max="100" name="platform_charge" value="<?php echo e($settings['platform_charge'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Sell Commission')); ?> (%) <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="number" min="0" max="100" name="sell_commission" value="<?php echo e($settings['sell_commission'] ?? ''); ?>" class="form-control" required>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label for="allow_preloader" class="col-lg-3"><?php echo e(__('Allow Preloader')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <select name="allow_preloader" class="form-control">
                                                <option value=""><?php echo e(__('Select Option')); ?></option>
                                                <option value="1" <?php if($settings['allow_preloader'] ?? '' == 1): ?> selected <?php endif; ?>><?php echo e(__('Active')); ?></option>
                                                <option value="0" <?php if($settings['allow_preloader'] ?? '' != 1): ?> selected <?php endif; ?>><?php echo e(__('Disable')); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Preloader')); ?></label>
                                        <div class="col-lg-4">
                                            <div class="upload-img-box">
                                                <?php if($settings['app_preloader'] ?? ''): ?>
                                                    <img src="<?php echo e(getImageFile($settings['app_preloader'])); ?>">
                                                <?php else: ?>
                                                    <img src="">
                                                <?php endif; ?>
                                                <input type="file" name="app_preloader" id="app_preloader" accept="image/*" onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('Preloader')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('app_preloader')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('app_preloader')); ?></span>
                                            <?php endif; ?>
                                            <p><span class="text-black"><?php echo e(__('Accepted Files')); ?>:</span> PNG, SVG <br> <span class="text-black"><?php echo e(__('Recommend Size')); ?>:</span> 118 x 40</p>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Logo')); ?></label>
                                        <div class="col-lg-4">
                                            <div class="upload-img-box">
                                                <?php if($settings['app_logo'] ?? ''): ?>
                                                    <img src="<?php echo e(getImageFile($settings['app_logo'])); ?>">
                                                <?php else: ?>
                                                    <img src="">
                                                <?php endif; ?>
                                                <input type="file" name="app_logo" id="app_logo" accept="image/*" onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('App Logo')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('app_logo')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('app_logo')); ?></span>
                                            <?php endif; ?>
                                            <p><span class="text-black"><?php echo e(__('Accepted Files')); ?>:</span> PNG, SVG <br> <span class="text-black"><?php echo e(__('Recommend Size')); ?>:</span> 140 x 40</p>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Black Logo')); ?></label>
                                        <div class="col-lg-4">
                                            <div class="upload-img-box">
                                                <?php if($settings['app_black_logo'] ?? ''): ?>
                                                    <img src="<?php echo e(getImageFile($settings['app_black_logo'])); ?>">
                                                <?php else: ?>
                                                    <img src="">
                                                <?php endif; ?>
                                                <input type="file" name="app_black_logo" id="app_black_logo" accept="image/*" onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('App Black Logo')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('app_black_logo')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('app_black_logo')); ?></span>
                                            <?php endif; ?>
                                            <p><span class="text-black"><?php echo e(__('Accepted Files')); ?>:</span> PNG, SVG <br> <span class="text-black"><?php echo e(__('Recommend Size')); ?>:</span> 140 x 40</p>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Fav Icon')); ?></label>
                                        <div class="col-lg-4">
                                            <div class="upload-img-box">
                                                <?php if($settings['app_fav_icon'] ?? ''): ?>
                                                    <img src="<?php echo e(getImageFile($settings['app_fav_icon'])); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('uploads/default/no-image-found.png')); ?>">
                                                <?php endif; ?>
                                                <input type="file" name="app_fav_icon" id="app_fav_icon" accept="image/*" onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('App Fav Icon')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('app_fav_icon')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('app_fav_icon')); ?></span>
                                            <?php endif; ?>
                                            <p><span class="text-black"><?php echo e(__('Accepted Files')); ?>:</span> PNG, SVG <br> <span class="text-black"><?php echo e(__('Recommend Size')); ?>:</span> 16 x 16</p>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('App Footer Payment Banner')); ?></label>
                                        <div class="col-lg-4">
                                            <div class="upload-img-box">
                                                <?php if($settings['app_footer_payment_image'] ?? ''): ?>
                                                    <img src="<?php echo e(getImageFile($settings['app_footer_payment_image'])); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('uploads/default/no-image-found.png')); ?>">
                                                <?php endif; ?>
                                                <input type="file" name="app_footer_payment_image" id="app_footer_payment_image" accept="image/*" onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('App Footer Payment Banner')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('app_footer_payment_image')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo e($errors->first('app_footer_payment_image')); ?></span>
                                            <?php endif; ?>
                                            <p><span class="text-black"><?php echo e(__('Accepted Files')); ?>:</span> PNG, SVG <br> <span class="text-black"><?php echo e(__('Recommend Size')); ?>:</span> 780 x 80</p>
                                        </div>
                                    </div>
                                    <br>

                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Forgot Title')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="forgot_title" value="<?php echo e($settings['forgot_title'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Forgot Subtitle')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="forgot_subtitle" value="<?php echo e($settings['forgot_subtitle'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Forgot Button Name')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="forgot_btn_name" value="<?php echo e($settings['forgot_btn_name'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Footer Quote')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <textarea class="form-control" name="footer_quote" rows="5"><?php echo e($settings['footer_quote'] ?? ''); ?></textarea>
                                        </div>
                                    </div>

                                    <hr>

                                    <div class="item-top mb-30"><h2><?php echo e(__('Social Media Profile Link')); ?></h2></div>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Facebook URL')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="facebook_url" value="<?php echo e($settings['facebook_url'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Twitter URL')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="twitter_url" value="<?php echo e($settings['twitter_url'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('LinkedIn URL')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="linkedin_url" value="<?php echo e($settings['linkedin_url'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('YouTube URL')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="youtube_url" value="<?php echo e($settings['youtube_url'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Instagram URL')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="instagram_url" value="<?php echo e($settings['instagram_url'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row input__group mb-25">
                                        <label class="col-lg-3"><?php echo e(__('Tiktok URL')); ?> <span class="text-danger">*</span></label>
                                        <div class="col-lg-9">
                                            <input type="text" name="tiktok_url" value="<?php echo e($settings['tiktok_url'] ?? ''); ?>" class="form-control">
                                        </div>
                                    </div>

                                    <br>
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="input__group general-settings-btn">
                                                <button type="submit" class="btn btn-primary btn-sm float-right"><?php echo e(__('Update')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                    <br>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>


    <!-- Page content area end -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aasif\Desktop\margaritaAPis\resources\views/admin/application_settings/general/general-settings.blade.php ENDPATH**/ ?>