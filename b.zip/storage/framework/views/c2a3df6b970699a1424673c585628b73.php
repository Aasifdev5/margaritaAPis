<?php $__env->startSection('title'); ?>
LISTA DE BANNERS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e(session::get('success')); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if(Session::has('fail')): ?>
                    <div class="alert alert-danger">
                        <p><?php echo e(session::get('fail')); ?></p>
                    </div>
                    <?php endif; ?>
                    <div class="card-header">
                        <h5> LISTA DE BANNERS</h5>
                        <a class="btn btn-pill btn-primary btn-air-primary pull-right" href="<?php echo e(route('admin.banners.create')); ?>" data-toggle="tooltip" title="" role="button" data-bs-original-title="btn btn-primary">Agregar banner</a>
                    </div>
                    <div class="card-body">
                        <form id="bulk-delete-form" action="<?php echo e(route('admin.banners.bulkDestroy')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <button type="submit" class="btn btn-danger" id="bulk-delete-btn" disabled>Eliminar Seleccionados</button>
                            </div>
                            <div class="table-responsive">
                                <table class="display" id="basic-1">
                                    <thead>
                                        <tr>
                                            <th class="text-center">
                                                <input type="checkbox" id="select-all">
                                            </th>
                                            <th>Título 1</th>
                                            <th>Título 2</th>
                                            <th>Título 3</th>
                                            <th>Botón</th>
                                            <th>Enlace de botón</th>
                                            <th>Banner</th>
                                            <th>Acción</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $count = 1; ?>
                                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-center">
                                                <input type="checkbox" class="banner-checkbox" name="banners[]" value="<?php echo e($row->id); ?>">
                                            </td>
                                            <td><?php echo e($row->title1); ?></td>
                                            <td><?php echo e($row->title2); ?></td>
                                            <td><?php echo e($row->title3); ?></td>
                                            <td><?php echo e($row->button); ?></td>
                                            <td><?php echo e($row->link); ?></td>
                                            <td><img src="<?php echo e(asset($row->image)); ?>" alt="<?php echo e($row->title1); ?>" width="100" height="100"></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.banners.edit', ['banner' => $row->id])); ?>" class="btn btn-sm btn-success">
                                                    <i class="fa fa-edit"></i> Editar
                                                </a>
                                                <button type="button" class="btn btn-sm btn-danger" onclick="event.preventDefault(); confirmDelete('<?php echo e($row->id); ?>');">
                                                    <i class="fa fa-trash"></i> Eliminar
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert Library -->
<script>
    // SweetAlert for single delete confirmation
    function confirmDelete(bannerId) {
        Swal.fire({
            title: "¿Estás seguro?",
            text: "¡Este banner se eliminará permanentemente!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
            dangerMode: true,
        }).then((result) => {
            if (result.isConfirmed) {
                // You can call the delete form submission here if needed
                document.getElementById('delete-form-' + bannerId).submit();
            }
        });
    }

    // Select/Deselect all checkboxes
    document.getElementById('select-all').addEventListener('change', function(e) {
        const checkboxes = document.querySelectorAll('.banner-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = e.target.checked;
        });
        toggleBulkDeleteButton();
    });

    // Enable/Disable bulk delete button based on checkbox selection
    document.querySelectorAll('.banner-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', toggleBulkDeleteButton);
    });

    function toggleBulkDeleteButton() {
        const checkedCount = document.querySelectorAll('.banner-checkbox:checked').length;
        const bulkDeleteButton = document.getElementById('bulk-delete-btn');
        bulkDeleteButton.disabled = checkedCount === 0;
    }

    // SweetAlert for bulk delete confirmation
    document.getElementById('bulk-delete-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const form = this;
        Swal.fire({
            title: "¿Estás seguro?",
            text: "¡Estos banners se eliminarán permanentemente!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar',
            dangerMode: true,
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aasif\Desktop\margaritaAPis\resources\views/admin/banners/index.blade.php ENDPATH**/ ?>