<?php $__env->startSection('title'); ?>
    Editar categoria
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>

        <div class="container">


                <div class="card mt-4 p-4" >
                    <div class="text-center"><img src="assets/images/endless-logo.png" alt=""></div>
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-vertical__item bg-style">
                                    <div class="item-top mb-30">
                                        <h2><?php echo e(__('Editar categoria')); ?></h2>
                                    </div>
                                    <form id="Form" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="input__group mb-25">
                                            <label for="name"> <?php echo e(__('Nombre')); ?> </label>
                                            <div>
                                                <input type="text" name="name" id="name"
                                                    value="<?php echo e($category->name); ?>" class="form-control flat-input"
                                                    placeholder=" <?php echo e(__('Nombre')); ?> ">
                                                <?php if($errors->has('name')): ?>
                                                    <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                        <?php echo e($errors->first('name')); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="input__group mb-25">
                                            <label for="is_feature"> <?php echo e(__('Función')); ?> </label>
                                            <div>
                                                <label class="text-black"> <input type="checkbox" name="is_feature"
                                                        id="is_feature" value="yes"
                                                        <?php echo e($category->is_feature == 'yes' ? 'checked' : ''); ?>>
                                                    <?php echo e(__('Sí')); ?> </label>
                                            </div>
                                        </div>

                                        <div class="custom-form-group mb-25 ">
                                            <label for="image" class="text-lg-right text-black mb-2">
                                                <?php echo e(__('Imagen')); ?> </label>
                                            <div class="upload-img-box mb-25">
                                                <?php if($category->image): ?>
                                                    <img src="<?php echo e(asset($category->image_path)); ?>">
                                                <?php else: ?>
                                                    <img src="">
                                                <?php endif; ?>
                                                <input type="file" name="image" id="image" accept="image/*"
                                                    onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('Imagen')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('image')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                    <?php echo e($errors->first('image')); ?></span>
                                            <?php endif; ?>
                                            <p><?php echo e(__('Archivos Aceptados')); ?>: PNG <br> <?php echo e(__('Tamaño Recomendado')); ?>: 60 x
                                                60 (1MB)</p>
                                        </div>

                                        <div class="input__group mb-25">
                                            <label><?php echo e(__('Título Meta')); ?></label>
                                            <input type="text" name="meta_title"
                                                value="<?php echo e(old('meta_title', $category->meta_title)); ?>"
                                                placeholder="<?php echo e(__('Título Meta')); ?>" class="form-control">
                                            <?php if($errors->has('meta_title')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                    <?php echo e($errors->first('meta_title')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="input__group mb-25">
                                            <label><?php echo e(__('Descripción Meta')); ?></label>
                                            <input type="text" name="meta_description"
                                                value="<?php echo e(old('meta_description', $category->meta_description)); ?>"
                                                placeholder="<?php echo e(__('Descripción Meta')); ?>" class="form-control">
                                            <?php if($errors->has('meta_description')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                    <?php echo e($errors->first('meta_description')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="input__group mb-25">
                                            <label><?php echo e(__('Palabras Clave Meta')); ?></label>
                                            <input type="text" name="meta_keywords"
                                                value="<?php echo e(old('meta_keywords', $category->meta_keywords)); ?>"
                                                placeholder="<?php echo e(__('Palabras Clave Meta')); ?>" class="form-control">
                                            <?php if($errors->has('meta_keywords')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                    <?php echo e($errors->first('meta_keywords')); ?></span>
                                            <?php endif; ?>
                                        </div>

                                        <div class="input__group mb-25">
                                            <label><?php echo e(__('Imagen OG')); ?></label>
                                            <div class="upload-img-box">
                                                <?php if($category->og_image != null && $category->og_image != ''): ?>
                                                    <img src="<?php echo e(getImageFile($category->og_image)); ?>">
                                                <?php else: ?>
                                                    <img src="">
                                                <?php endif; ?>
                                                <input type="file" name="og_image" id="og_image" accept="image/*"
                                                    onchange="previewFile(this)">
                                                <div class="upload-img-box-icon">
                                                    <i class="fa fa-camera"></i>
                                                    <p class="m-0"><?php echo e(__('Imagen OG')); ?></p>
                                                </div>
                                            </div>
                                            <?php if($errors->has('og_image')): ?>
                                                <span class="text-danger"><i class="fas fa-exclamation-triangle"></i>
                                                    <?php echo e($errors->first('og_image')); ?></span>
                                            <?php endif; ?>
                                            <p><span class="text-black"><?php echo e(__('Archivos Aceptados')); ?>:</span> PNG, JPG <br>
                                                <span class="text-black"><?php echo e(__('Tamaño Recomendado')); ?>:</span> 1200 x 627
                                            </p>
                                        </div>

                                        <div class="input__group">
                                            <div>
                                                <button class="btn btn-primary" type="submit">Actualizar</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

        </div>


   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $('#Form').submit(function(e) {
        e.preventDefault();

        let formData = new FormData(this);

        $.ajax({
            type: "POST",
            url: "<?php echo e(route('category.update', [$category->uuid])); ?>",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Éxito!',
                        text: 'Categoría actualizada correctamente.',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        window.location.href = "<?php echo e(route('category.index')); ?>";
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'No se pudo actualizar la categoría.'
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                Swal.fire({
                    icon: 'error',
                    title: 'Error del servidor',
                    text: 'No se pudo actualizar la categoría. Por favor, inténtelo de nuevo más tarde.'
                });
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aasif\Desktop\margaritaAPis\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>