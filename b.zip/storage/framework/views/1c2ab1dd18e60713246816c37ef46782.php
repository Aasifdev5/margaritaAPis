  <!-- latest jquery-->
  <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
  <!-- Bootstrap js-->
  <script src="<?php echo e(asset('assets/js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
  <!-- feather icon js-->
  <script src="<?php echo e(asset('assets/js/icons/feather-icon/feather.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/icons/feather-icon/feather-icon.js')); ?>"></script>
  <!-- scrollbar js-->
  <script src="<?php echo e(asset('assets/js/scrollbar/simplebar.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/scrollbar/custom.js')); ?>"></script>
  <!-- Sidebar jquery-->
  <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/sidebar-menu.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.sparkline2.1.2.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/datatable/datatables/datatable.custom.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/tooltip-init.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/editor/ckeditor/ckeditor.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/editor/ckeditor/adapters/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/editor/ckeditor/styles.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/editor/ckeditor/ckeditor.custom.js')); ?>"></script>


  
  <?php echo $__env->yieldContent('scripts'); ?>
  

   <!-- Template js-->
   <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/theme-customizer/customizer.js')); ?>"></script>
   <!-- login js-->
<?php /**PATH C:\Users\Aasif\Desktop\margaritaAPis\resources\views/layout/script.blade.php ENDPATH**/ ?>