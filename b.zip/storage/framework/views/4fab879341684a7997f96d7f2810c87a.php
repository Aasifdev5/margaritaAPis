<?php $__env->startSection('title'); ?>
    Editar banner
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
    <!-- page-wrapper Start-->

        <div class="container">

                <div class="card mt-4 p-4" >
                    <div class="card-body">
                        <h4 class="text-center">Editar banner</h4>

                        <!-- Form to edit an existing banner -->
                        <form action="<?php echo e(route('admin.banners.update', $banner->id)); ?>" class="theme-form" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <p><?php echo e(session('success')); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('fail')): ?>
                                <div class="alert alert-danger">
                                    <p><?php echo e(session('fail')); ?></p>
                                </div>
                            <?php endif; ?>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="title1">Título 1:</label>
                                        <input type="text" class="form-control" name="title1" value="<?php echo e(old('title1', $banner->title1)); ?>">
                                        <?php $__errorArgs = ['title1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="title2">Título 2:</label>
                                        <input type="text" class="form-control" name="title2" value="<?php echo e(old('title2', $banner->title2)); ?>">
                                        <?php $__errorArgs = ['title2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="title3">Título 3:</label>
                                        <input type="text" class="form-control" name="title3" value="<?php echo e(old('title3', $banner->title3)); ?>">
                                        <?php $__errorArgs = ['title3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="button">Botón:</label>
                                        <input type="text" class="form-control" name="button" value="<?php echo e(old('button', $banner->button)); ?>" placeholder="Texto del botón">
                                        <?php $__errorArgs = ['button'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="link">Enlace de botón:</label>
                                        <input type="text" class="form-control" name="link" value="<?php echo e(old('link', $banner->link)); ?>" placeholder="https://example.com">
                                        <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="image">Imagen:</label>
                                        <input type="file" class="form-control" id="image" name="image" accept="image/*">
                                        <img id="preview" src="#" alt="Imagen Preview" style="display:none; width: 100%; max-width: 500px; margin-top: 10px;" />
                                        <span>Image must 1920*1280 Dimension</span>
                                    </div>

                                    <script>
                                        document.getElementById('image').addEventListener('change', function(event) {
                                            var reader = new FileReader();
                                            reader.onload = function() {
                                                var preview = document.getElementById('preview');
                                                preview.src = reader.result;
                                                preview.style.display = 'block';
                                            }
                                            reader.readAsDataURL(event.target.files[0]);
                                        });

                                        // Set preview if there's an existing image
                                        window.onload = function() {
                                            var preview = document.getElementById('preview');
                                            var existingImage = "<?php echo e(asset($banner->image)); ?>";
                                            preview.src = existingImage;
                                            preview.style.display = 'block';
                                        }
                                    </script>
                                </div>

                                <div class="col-sm-6 text-center">
                                    <img src="<?php echo e(asset('Screenshot (317).png')); ?>" width="300px" alt="Ejemplo de Banner" class="img-fluid" style="margin-top: 20px;">
                                </div>
                            </div>

                            <br>
                            <button type="submit" class="btn btn-primary">Actualizar banner</button>
                        </form>
                    </div>

                </div>

        </div>
        <!-- sign up page ends-->

    <!-- page-wrapper Ends-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aasif\Desktop\margaritaAPis\resources\views/admin/banners/edit.blade.php ENDPATH**/ ?>